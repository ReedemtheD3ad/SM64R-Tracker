-- Load items
Tracker:AddItems("cannons.json")
Tracker:AddItems("doors.json")
Tracker:AddItems("font.json")
Tracker:AddItems("keys.json")
Tracker:AddItems("paintings.json")
Tracker:AddItems("stars.json")
Tracker:AddItems("switches.json")
-- Load layouts
Tracker:AddLayouts("layout.json")